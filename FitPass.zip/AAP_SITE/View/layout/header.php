    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/index.css">
        <title><?php echo $pageTitle; ?></title>
    </head>
    <body>
        <header>
            <nav>
                <div class="navbar">
                    <ul>
                        <li style="text-align: left"><a href="index.php">Fitpass</a></li>
                        <li><a href="exercicio.php">Exercícios</a></li>
                        <li><a href="suplementos.php">Suplementos</a></li>
                        <li><a href="alimentos.php">Alimentos</a></li>
                        <li><a href="login.php">Login</a></li>
                    </ul>
                </div>
            </nav>
        </header>
        <br><br><br><br>
    </body>